package com.subex.brokenarrow.model;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class IncidentViewFilters 
{
	private String risk_category; 
	private String process_percentage;
	private String issue_since;
	private String product;
	private String region;
	
	public IncidentViewFilters()
	{
		
	}

	public String getRisk_category() {
		return risk_category;
	}
	public void setRisk_category(String risk_category) {
		this.risk_category = risk_category;
	}
	public String getProcess_percentage() {
		return process_percentage;
	}
	public void setProcess_percentage(String process_percentage) {
		this.process_percentage = process_percentage;
	}
	public String getIssue_since() {
		return issue_since;
	}
	public void setIssue_since(String issue_since) {
		this.issue_since = issue_since;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
}
