package com.subex.brokenarrow.service;

import com.subex.brokenarrow.database.DBConnection;
import com.subex.brokenarrow.model.LoginDetails;
import com.subex.brokenarrow.model.ProfileDetails;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("/login")  // Path: http://localhost:8081/Broken_Arrow_App/login
public class Login 
{
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON) 
    public ProfileDetails doLogin(LoginDetails log_det)
    {
  	  	String uname = log_det.getUsername();
  	  	String pwd = log_det.getPassword();
  	  	System.out.println("User "+uname+" Trying to login with Password as "+pwd);
  	  	ProfileDetails prof_det=new ProfileDetails();
  	  	if(checkCredentials(uname, pwd))
  	  	{
  	  		String device_id=log_det.getDevice_id();
  	  		String os_type=log_det.getOs_type();
  	  		//Update Details of Device and OS and last access
  	  		//response = Utility.constructJSON("login",true);
  	  		//updateDeviceInfo();
  	  		try
  	  		{
  	  			DBConnection.updateUserDetails(uname,device_id,os_type);
  	  			prof_det=DBConnection.getProfileDetails(uname);
  	  		}
  	  		catch(Exception e)
  	  		{}
  	  	}
  	  	else
  	  	{
            //response = Utility.constructJSON("login", false, "Incorrect Email or Password");
  	  		prof_det.setEmail(null);
  	  		prof_det.setFull_name(null);
  	  		prof_det.setStatus(false);
  	  		prof_det.setMessage("Incorrect Username/Password");
        }
        return prof_det;        
    }
    
   /* @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ProfileDetails doLogin() 
    {
    	ProfileDetails prof_det=new ProfileDetails();
    	prof_det.setEmail("bsaik7@gmail.com");
	  	prof_det.setFull_name("Sai");
	  	prof_det.setStatus(false);
	  	prof_det.setMessage("Incorrect Username/Password");
	  	return prof_det;
    } */
 
	//Method to check whether the entered credential is valid
    private boolean checkCredentials(String uname, String pwd)
    {
    	System.out.println("ENtered check Credentials");
        boolean result = false;
        if(isNotNull(uname) && isNotNull(pwd)){
            try 
            {
                result = DBConnection.checkLogin(uname, pwd);
            } 
            catch (Exception e) 
            {
                result = false;
            }
        }
        else
        {
        	result = false;
        }
        
        return result;
    }
    
    public static boolean isNotNull(String txt) 
    {
        return txt != null && txt.trim().length() >= 0 ? true : false;
    }
    
}
