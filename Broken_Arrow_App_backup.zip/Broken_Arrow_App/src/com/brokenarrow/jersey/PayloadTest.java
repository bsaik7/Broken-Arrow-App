package com.brokenarrow.jersey;


import javax.ws.rs.Consumes;
//import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//Path: http://localhost/<appln-folder-name>/login
@Path("/logintest")
public class PayloadTest 
{
  // HTTP Get Method
  @POST
  // Path: http://localhost/<appln-folder-name>/login/dologin
  @Path("/sai1")
  // Produces JSON as response
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON) 
  // Query parameters are parameters: http://localhost/<appln-folder-name>/login/dologin?username=abc&password=xyz
  public String doLogin(Order order) 
  {
	  String uname = order.getUsername();
	  String pwd = order.getPassword();
	  System.out.println(uname+pwd);
	  String response = "";
      if(checkCredentials(uname, pwd)){
          response = Utility.constructJSON("login",true);
      }else{
          response = Utility.constructJSON("login", false, "Incorrect Email or Password");
      }
  return response;        
  }
  /*
  @XmlRootElement
  public class RequestBody {
      @XmlElement public String username;
      @XmlElement public String password;
      //@XmlElement Integer count;
  }
*/
  //Method to check whether the entered credential is valid

  private boolean checkCredentials(String uname, String pwd){
      //System.out.println("Inside checkCredentials");
      boolean result = false;
      if(Utility.isNotNull(uname) && Utility.isNotNull(pwd)){
          if(uname.equals("bat")&&pwd.equals("sai"))
        	  result=true;
          else
        	  result=false;
      }else{
          //System.out.println("Inside checkCredentials else");
          result = false;
      }

      return result;
  }
}
