package com.subex.brokenarrow.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.subex.brokenarrow.model.CustomerDetails;
import com.subex.brokenarrow.model.ProfileDetails;
 
public class DBConnection {
    // Method to create DB Connection
    @SuppressWarnings("finally")
    public static Connection createConnection() throws Exception 
    {
        Connection con = null;
        try 
        {
            Class.forName(Constants.dbClass);
            con = DriverManager.getConnection(Constants.dbUrl, Constants.dbUser, Constants.dbPwd);
        } 
        catch (Exception e) 
        {
            throw e;
        } 
        finally 
        {
            return con;
        }
    }
    // Method to check whether uname and pwd combination are correct

    public static boolean checkLogin(String uname, String pwd) throws Exception 
    {
        boolean isUserAvailable = false;
        Connection dbConn = null;
        try {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Statement stmt = dbConn.createStatement();
            String query = "SELECT * FROM app_user_details WHERE email_id = '" + uname
                    + "' AND password=" + "'" + pwd + "'";
            //System.out.println(query);
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
                //System.out.println(rs.getString(1) + rs.getString(2) + rs.getString(3));
                isUserAvailable = true;
            }
        } 
        catch (SQLException sqle) 
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
        System.out.println(isUserAvailable);
        return isUserAvailable;
    }
    
    
    //Returning Profile Details
    public static ProfileDetails getProfileDetails(String uname) throws Exception 
    {
        Connection dbConn = null;
        ProfileDetails prof_det=new ProfileDetails();
        prof_det.setEmail(uname);
        prof_det.setStatus(true);
	  	prof_det.setMessage("Login Successfull");
        try {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Statement stmt = dbConn.createStatement();
            String query = "SELECT username FROM app_user_details WHERE email_id = '" + uname + "'";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
                prof_det.setFull_name(rs.getString(1));        
            	//System.out.println(rs.getString(1) + rs.getString(2) + rs.getString(3));
            }
        } 
        catch (SQLException sqle) 
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
        return prof_det;
    }
    
    
    //Updating The App User Details
    public static void updateUserDetails(String uname, String device_id, String os_type) throws SQLException, Exception 
    {
        Connection dbConn = null;
        try 
        {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                e.printStackTrace();
            }
          
            boolean isUserPresent=false;
  
            Statement stmt = dbConn.createStatement();
            String query = "SELECT * FROM app_user_info WHERE email_id = '" +uname+ "'";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
            	isUserPresent = true;
            }
            if(isUserPresent)
            {
            	//execute Update
            	Date last_login_time= new Date();
            	Statement updtae_stmt = dbConn.createStatement();
                String update_query = "UPDATE app_user_info SET  device_id= '"+ device_id +"', os_platform = '"+ os_type +"' , last_login_time= '"+ last_login_time+"'"
                    + "WHERE email_id = '"+uname+"';";

                updtae_stmt.execute(update_query);

            }
            else
            {
            	//Insert New data
            	int id=1;
            	
            	//Generate ID;
            	
                String id_query = "SELECT max(id) FROM app_user_info";
                PreparedStatement id_stmt = dbConn.prepareStatement(id_query);
                ResultSet id_rs = id_stmt.executeQuery();
                
                while (id_rs.next()) 
                {
                	id=id_rs.getInt(1)+1;
                }
            	Date last_login_time= new Date();
            	Statement insert_stmt = dbConn.createStatement();
            	String insert_query = "INSERT into app_user_info(id, device_id, os_platform, last_login_time, email_id) values("+id+",'"+device_id+ "','"
                         + os_type + "','" + last_login_time +"','" + uname+ "')";
            	
            	int records = insert_stmt.executeUpdate(insert_query);
            	if(records>0)
            	{
            		System.out.println(uname+" Inserted Successfully at "+last_login_time);
            	}
            }
           
        } 
        catch (SQLException sqle)
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
    }
    
    
    //Get the Customer Based on Filters
    
    public static List<CustomerDetails> getRiskyCustomerDetails(String region,String product) throws Exception 
    {
        Connection dbConn = null;
        List<CustomerDetails> cust_list=new ArrayList<CustomerDetails>();
	  	try {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Statement stmt = dbConn.createStatement();
            String query = "SELECT CUST_ID,CUST_NAME,Region,Product,RECEIVED_DATE,OVERALL_STATUS,RISK_PERCENTAGE,ACK_BY,ACK_DATE,ETA_DURATION,ISSUE_RUNNING_SINCE  FROM CUSTOMER_LATEST_STATUS WHERE OVERALL_STATUS='Red' and region in " + region + "' and product in "+product+" order by RISK_PERCENTAGE desc";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
            	CustomerDetails cust_det=new CustomerDetails();
            	cust_det.setCust_id(rs.getString(1));
            	cust_det.setCust_name(rs.getString(2));
            	cust_det.setRegion(rs.getString(3));
            	cust_det.setProduct(rs.getString(4));
            	cust_det.setReceived_date(rs.getString(5));
            	cust_det.setOverall_status(rs.getString(6));
            	cust_det.setRisk_percentage(rs.getInt(7));
            	cust_det.setAck_by(rs.getString(8));
            	cust_det.setAck_date(rs.getString(9));
            	cust_det.setEta_duration(rs.getString(10));
            	cust_det.setIssue_running_since(rs.getString(11));
            	cust_list.add(cust_det);
                //prof_det.setFull_name(rs.getString(1));        
            	//System.out.println(rs.getString(1) + rs.getString(2) + rs.getString(3));
            }
        } 
        catch (SQLException sqle) 
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
        return cust_list;
    }
    
    //Customers End
    
    
}
