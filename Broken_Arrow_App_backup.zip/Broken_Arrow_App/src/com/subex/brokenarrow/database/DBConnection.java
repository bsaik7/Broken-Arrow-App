package com.subex.brokenarrow.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.subex.brokenarrow.model.ProfileDetails;
 
public class DBConnection {
    // Method to create DB Connection
    @SuppressWarnings("finally")
    public static Connection createConnection() throws Exception 
    {
        Connection con = null;
        try 
        {
            Class.forName(Constants.dbClass);
            con = DriverManager.getConnection(Constants.dbUrl, Constants.dbUser, Constants.dbPwd);
        } 
        catch (Exception e) 
        {
            throw e;
        } 
        finally 
        {
            return con;
        }
    }
    // Method to check whether uname and pwd combination are correct

    public static boolean checkLogin(String uname, String pwd) throws Exception 
    {
        boolean isUserAvailable = false;
        Connection dbConn = null;
        try {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Statement stmt = dbConn.createStatement();
            String query = "SELECT * FROM app_user_details WHERE username = '" + uname
                    + "' AND password=" + "'" + pwd + "'";
            //System.out.println(query);
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
                //System.out.println(rs.getString(1) + rs.getString(2) + rs.getString(3));
                isUserAvailable = true;
            }
        } 
        catch (SQLException sqle) 
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
        System.out.println(isUserAvailable);
        return isUserAvailable;
    }
    
    
    //Returning Profile Details
    public static ProfileDetails getProfileDetails(String uname) throws Exception 
    {
        Connection dbConn = null;
        ProfileDetails prof_det=new ProfileDetails();
        prof_det.setEmail(uname);
        prof_det.setStatus(true);
	  	prof_det.setMessage("Login Successfull");
        try {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Statement stmt = dbConn.createStatement();
            String query = "SELECT name FROM app_user_details WHERE username = '" + uname + "'";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
                prof_det.setFull_name(rs.getString(1));        
            	//System.out.println(rs.getString(1) + rs.getString(2) + rs.getString(3));
            }
        } 
        catch (SQLException sqle) 
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
        return prof_det;
    }
    
    
    //Updating The App User Details
    public static void updateUserDetails(String uname, String device_id, String os_type) throws SQLException, Exception 
    {
        Connection dbConn = null;
        try 
        {
            try 
            {
                dbConn = DBConnection.createConnection();
            } 
            catch (Exception e) 
            {
                e.printStackTrace();
            }
          
            boolean isUserPresent=false;
  
            Statement stmt = dbConn.createStatement();
            String query = "SELECT * FROM app_user_info WHERE email_id = '" +uname+ "'";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) 
            {
            	isUserPresent = true;
            }
            if(isUserPresent)
            {
            	//execute Update
            	Date last_login_time= new Date();
            	Statement updtae_stmt = dbConn.createStatement();
                String update_query = "UPDATE app_user_info SET  device_id= '"+ device_id +"', os_platform = '"+ os_type +"' , last_login_time= '"+ last_login_time+"'"
                    + "WHERE email_id = '"+uname+"';";

                updtae_stmt.execute(update_query);

            }
            else
            {
            	//Insert New data
            	int id=1;
            	
            	//Generate ID;
            	Statement id_stmt = dbConn.createStatement();
                String id_query = "SELECT max(id) FROM app_user_info";
                ResultSet id_rs = id_stmt.executeQuery(id_query);
                while (id_rs.next()) 
                {
                	id=rs.getInt(1)+1;
                }
            	
            	Date last_login_time= new Date();
            	Statement insert_stmt = dbConn.createStatement();
            	String insert_query = "INSERT into app_user_info(id, device_id, os_platform, last_login_time, email_id) values("+id+",'"+device_id+ "','"
                         + os_type + "','" + last_login_time +"','" + uname+ "')";
            	int records = insert_stmt.executeUpdate(insert_query);
            	if(records>0)
            	{
            		System.out.println(uname+" Inserted Successfully at "+last_login_time);
            	}
            }
           
        } 
        catch (SQLException sqle)
        {
            throw sqle;
        } 
        catch (Exception e) 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
            throw e;
        } 
        finally 
        {
            if (dbConn != null) 
            {
                dbConn.close();
            }
        }
    }
    
}
