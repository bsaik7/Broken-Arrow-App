package com.subex.brokenarrow.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FilterDetails 
{
	private String region; 
	private String product;
	
	public FilterDetails()
	{}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	
}
