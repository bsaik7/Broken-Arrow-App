package com.subex.brokenarrow.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProfileDetails 
{
	private String full_name;
	private boolean status;
	private String email;
	private String message;
	
	//Getters and Setters
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
