package com.subex.brokenarrow.database;

//My SQL DB Parameters
public class Constants {
  public static String dbClass = "com.mysql.jdbc.Driver";
  private static String dbName= "customer_status";
  public static String dbUrl = "jdbc:mysql://10.113.59.147:3306/"+dbName;
  public static String dbUser = "sai";
  public static String dbPwd = "sai";
  public static int risk_threshold=30;
}