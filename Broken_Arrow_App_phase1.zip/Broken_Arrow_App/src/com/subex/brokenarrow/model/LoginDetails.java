package com.subex.brokenarrow.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LoginDetails 
{
	private String username; 
	private String password;
	private String device_id; //Mobile Device ID
	private String os_type; //Android or IOS

	
	public LoginDetails()
	{
		
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDevice_id() {
		return device_id;
	}
	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}
	public String getOs_type() {
		return os_type;
	}
	public void setOs_type(String os_type) {
		this.os_type = os_type;
	}
}
