package com.subex.brokenarrow.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProfileDetails 
{
	private String full_name;
	private boolean status;
	private String email;
	private String message;
	private List<String> all_region=new ArrayList<String>();
	private List<String> all_product=new ArrayList<String>();
	private List<RegionProductRiskPercentageDetails> region_product_risk=new ArrayList<RegionProductRiskPercentageDetails>();
	
	public ProfileDetails()
	{
		
	}
	
	public void setRegionProductRisk(List<RegionProductRiskPercentageDetails> rpr) 
	{
		this.region_product_risk=rpr;
//		System.out.println(region_product_risk);
	}
	public List<RegionProductRiskPercentageDetails> getRegion_product_risk() {
		return region_product_risk;
	}

	public List<String> getAll_region() {
		return all_region;
	}

	public void setAll_region(String region) {
		this.all_region.add(region) ;
	}

	public List<String> getAll_product() {
		return all_product;
	}

	public void setAll_product(String product) {
		this.all_product.add(product);
	}
	
	//Getters and Setters
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
