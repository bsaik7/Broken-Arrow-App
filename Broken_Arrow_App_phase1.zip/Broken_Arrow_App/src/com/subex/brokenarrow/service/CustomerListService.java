package com.subex.brokenarrow.service;

import com.subex.brokenarrow.database.DBConnection;
import com.subex.brokenarrow.model.CustomerDetails;
import com.subex.brokenarrow.model.FilterDetails;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
//import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("/customers")  // Path: http://localhost:8081/Broken_Arrow_App/home

public class CustomerListService 
	{
		@POST
	    @Consumes(MediaType.APPLICATION_JSON)
	    @Produces(MediaType.APPLICATION_JSON) 
	    public List<CustomerDetails> getCustomerDetails(FilterDetails filter)
	    {
	  	  	//System.out.println("Filter Region "+region+" and Product "+product);
	  	  	List<CustomerDetails> customer_list=new ArrayList<CustomerDetails>();
	  	  	try
	  	  	{
	  	  		customer_list=DBConnection.getRiskyCustomerDetails(filter.getRegion(),filter.getProduct()); 
	  	  	}
	  	 	catch(Exception e)
  	  		{}
			return customer_list;
	  	  	       
	    }
}
