package com.subex.brokenarrow.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class AllFiltersDetails 
{
	private List<String> all_region=new ArrayList<String>();
	private List<String> all_product=new ArrayList<String>();
	private List<String> all_risk_category=new ArrayList<String>();
	private List<String> all_risk_percentage=new ArrayList<String>();
	private List<String> all_issue_since=new ArrayList<String>();
	
	public AllFiltersDetails()
	{
		
	}
	public List<String> getAll_region() {
		return all_region;
	}

	public void setAll_region(String region) {
		this.all_region.add(region) ;
	}

	public List<String> getAll_product() {
		return all_product;
	}

	public void setAll_product(String product) {
		this.all_product.add(product);
	}

	public List<String> getAll_risk_category() {
		return all_risk_category;
	}

	public void setAll_risk_category(String risk_category) {
		this.all_risk_category.add(risk_category);
	}

	public List<String> getAll_process_percentage() {
		return all_risk_percentage;
	}

	public void setAll_risk_percentage(String risk_percentage) {
		this.all_risk_percentage.add(risk_percentage);
	}

	public List<String> getAll_issue_since() {
		return all_issue_since;
	}

	public void setAll_issue_since(String issue_since) {
		this.all_issue_since.add(issue_since);
	}

}
