package com.subex.brokenarrow.model;


import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDetails 
{
	private String cust_id; 
	private String cust_name;
	private String region;
	private String product;
	private String overall_status;
	private int risk_percentage;
	private String received_date;
	private String ack_by;
	private String ack_date;
	private String eta_duration;
	private String issue_running_since;
	private String risk_category;
		
	public CustomerDetails()
	{
		
	}

		
	public String getRisk_category() {
		return risk_category;
	}


	public void setRisk_category(String risk_category) {
		this.risk_category = risk_category;
	}


	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getOverall_status() {
		return overall_status;
	}
	public void setOverall_status(String overall_status) {
		this.overall_status = overall_status;
	}
	public int getRisk_percentage() {
		return risk_percentage;
	}
	public void setRisk_percentage(int risk_percentage) {
		this.risk_percentage = risk_percentage;
	}
	public String getReceived_date() {
		return received_date;
	}
	public void setReceived_date(String received_date) {
		this.received_date = received_date;
	}
	public String getAck_by() {
		return ack_by;
	}
	public void setAck_by(String ack_by) {
		this.ack_by = ack_by;
	}
	public String getAck_date() {
		return ack_date;
	}
	public void setAck_date(String ack_date) {
		this.ack_date = ack_date;
	}
	public String getEta_duration() {
		return eta_duration;
	}
	public void setEta_duration(String eta_duration) {
		this.eta_duration = eta_duration;
	}
	public String getIssue_running_since() {
		return issue_running_since;
	}
	public void setIssue_running_since(String issue_running_since) {
		this.issue_running_since = issue_running_since;
	}
	
}
