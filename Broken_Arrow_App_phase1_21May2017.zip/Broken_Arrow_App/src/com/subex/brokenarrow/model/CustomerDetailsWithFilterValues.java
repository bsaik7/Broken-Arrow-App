package com.subex.brokenarrow.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDetailsWithFilterValues 
{
	private List<CustomerDetails> customer_details=new ArrayList<CustomerDetails>();
	private AllFiltersDetails filters=new AllFiltersDetails();
	
	
	public CustomerDetailsWithFilterValues()
	{
		
	}

	public void setCustomerDetails(CustomerDetails cust_detail) 
	{
		this.customer_details.add(cust_detail);
//		System.out.println(region_product_risk);
	}
	public List<CustomerDetails> getCustomer_details() {
		return customer_details;
	}
	
	//Filter Getters and Setters
	public AllFiltersDetails getFilters() {
		return filters;
	}

	public void setFilters(AllFiltersDetails filters) {
		this.filters = filters;
	}
}
