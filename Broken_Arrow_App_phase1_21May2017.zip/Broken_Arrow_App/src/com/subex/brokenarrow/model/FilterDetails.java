package com.subex.brokenarrow.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FilterDetails 
{
	private String region; 
	private String product;
	private String start_date;
	private String end_date;
	
	public FilterDetails()
	{}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	
	
	
}
